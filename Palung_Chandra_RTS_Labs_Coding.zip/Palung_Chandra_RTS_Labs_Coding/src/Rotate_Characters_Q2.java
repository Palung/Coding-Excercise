/**
 *  This program takes a input of a string and has the overflow appear in the beginning.
 *  Assumes that overflow number is a input, or can be random.
 *  @author Palung Chandra
 */
import java.util.Random;
import java.util.Scanner;
public class Rotate_Characters_Q2{
	Random rand = new Random();
	/**
	 * Takes the input of user by command line.
	 * input of type String.
	 */
	private String input;
	/**
	 * The overflow value, taken by user.
	 * overflow of type int.
	 */
	private int overflow;
	/**
	 * The Constructor, initialzes the string of input, and the int of overflow.
	 * @param input of type string, and overflow of type int.
	 */
	public Rotate_Characters_Q2(String input, int overflow){
		this.input = input;
		this.overflow = overflow;
	}
	/**
	 * returns the input
	 * @return input.
	 */
	public String getInput(){
		return this.input;
	}
	/**
	 * Sets the input
	 * @param input of type String.
	 */
	public void setInput(String input){
		this.input = input;
		System.out.println("Input is "+input);
	}
	/**
	 * Returns the overflow value.
	 * @return overflow of type int.
	 */
	public int getOverflow(){
		return this.overflow;
	}
	/**
	 * Sets the overflow value by the user.
	 * Checks if the input is a integer and if the input value is equal or greater than 0, 
	 * and if the value is less than or equal to 10.
	 */
	public void setOverflow(){
		Scanner scan = new Scanner(System.in);
		int over = 0;
		System.out.println("overflow original: "+over);
		while(true){
			System.out.println("Enter the overflow number: ");
			String input = scan.next();
			//Check if the input is a integer.
			try{
				over = Integer.parseInt(input);
				System.out.println("Your overflow value is "+over);
				//Checks if input is greater than or equal to 0 AND if input is less than or equal to 10. Then stop, else go over.
				if(over>=0 && over<=this.input.length()){
					break;
				}
				else if(over<0){
					System.out.println("Number must be positive. ie 0 or greater.");
				}
				else{
					System.out.println("Number must be less or equal to length of input: "+this.input.length());
				}
			}
			catch(Exception e){
				System.out.println("Input is not a number, continue");
			}
		}
		System.out.println("overflow new: "+over);
		this.overflow = over;
	}
	/**
	 * Rotates the string based on the input and overflow.
	 * @param input of type String, overflow of type int.
	 * @return the rotated input of type String.
	 */
	public String rotate(String input, int overflow){
		/*
		 * We are given an input.  We place the overflow at the beginning.
		 * So we take the end part which is the measure of the input's lenght - the overflow and 
		 * place that in the begining.  Then for the remaining we take input's originial begining at index = 0
		 * and whatever is left until the overflow.
		 */
		return input.substring(input.length() - overflow, input.length()) + input.substring(0,input.length() - overflow);
	}
	/**
	 * Displays the input, overflow value, and the rotated input.
	 * @param input of type String, newString of type String, overflow of type int.
	 */
	public void displayString(String input, String newString, int overflow){
		System.out.println("\"" + input + "\"" + " rotated by "+overflow + " is "+ "\"" +newString+"\"");
	}
	public static void main(String args[]){
		Scanner scan = new Scanner(System.in);
		Rotate_Characters_Q2 rotating = new Rotate_Characters_Q2("",0);
		//Check if command line argument exist or not.
		String argument = "";
		while(args.length == 0){
			args = new String[1];
			System.out.println("What input would you like?");
			args[0] = scan.nextLine();
		}
		argument = args[0];
		rotating.setInput(argument);
		while(true){
			rotating.setOverflow();
			String newString = "";
			newString = rotating.rotate(rotating.getInput(),rotating.getOverflow());
			rotating.displayString(rotating.getInput(), newString, rotating.getOverflow());
			System.out.println("Do you want to keep going: any capitalization of yes counts.");
			String checker = scan.next();
			//If it it not any form of 'yes' then the program stops running.
			if(!checker.equalsIgnoreCase("yes")){
				System.out.println("Done");
				break;
			}
			System.out.println("What input would you like?");
			String input = scan.next();
			rotating.setInput(input);
		}
	}
}
