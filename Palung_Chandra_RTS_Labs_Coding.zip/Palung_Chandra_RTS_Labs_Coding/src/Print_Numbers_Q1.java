/**
 *  This program creates an array and takes a command line input to 
 *  print the number of integers in an array that are above the given input 
 *  and the number that are below.
 *  The values and size of the array will be random.
 *  Assumes that values of the array will be unordered.
 *  @author Palung Chandra
 */
import java.util.Random;
import java.util.Scanner;
public class Print_Numbers_Q1{
	//Create a new instance of Scanner
	Scanner scan = new Scanner(System.in);
	//Create a new instance of random
	Random rand = new Random();
	/*
	 * data of type int[]. To store the values of the array.
	 */
	private int data[];
	//capacity of type int.  The capacity of the data array.
	private int capacity;
	/**
	 * input of type int. The given input given by the command line argument.
	 */
	private int input;
	/**
	 * This is a constructor that takes initializes the size of data, and the value of input.
	 * @param capacity type int, input type int. 
	 */
	public Print_Numbers_Q1(int capacity, int input){
		this.capacity = capacity;
		this.input = input;
	}
	/**
	 * This sets the input number by parsing the argument to int.
	 * Checks if the arg is a number.
	 * If it is not it will repeat until user puts in a number.
	 * @param arg type String.
	 */
	public void setInput(String arg){
		while(true){
			try{
				this.input = Integer.parseInt(arg);
				break;
			}
			catch(Exception e){
				System.out.println("Input is not a number, continue");
			}
			System.out.println("Enter the overflow number: ");
			arg = scan.next();
		}
	}
	/**
	 * This returns the input as a int.
	 * @param none.
	 * @return this.input as type int.
	 */
	public int getInput(){
		return this.input;
	}
	/**
	 * This sets the array with random integers. The capacity is the number of entries to the array.
	 * @param capacity of type int.
	 */
	public void setArray(int capacity){
		//o(n) runtime, because we will be generating random integers for each index of the array.
		//Uses a for loop to generate random integers.
		data = new int[capacity];
		for(int i = 0; i<capacity;i++){
			data[i] = rand.nextInt(100);
		}
	}
	/**
	 * returns the data array.
	 * @return data of type int[].
	 */
	public int[] getArray(){
		return data;
	}
	/**
	 * Randomly sets the capacity based on the max.
	 * @param randomInput as int.
	 */
	public void setCapacity(int randomInput){
		this.capacity = rand.nextInt(randomInput);
	}
	/**
	 * Returns the capacity of the array
	 * @return this.capacity.
	 */
	public int getCapacity(){
		return this.capacity;
	}
	/**
	 * Iterates through the data array and compares the value to the input.
	 * Counts number entires that are the same, below and above the input.
	 * @param data of type int[]
	 * @return countOfNumbers of type int[] 
	 */
	public int[] countAboveAndBelow(int data[]){
		//int array to count number of same numbers, above numbers, and below numbers
		//index = 0 is same number, index= 1 is above number, and index = 2 is below number
		int[] countOfNumbers = new int[3];
		//Initialize countOfNumbers
		for(int i = 0; i<3; i++){
			countOfNumbers[i] = 0;
		}
		for(int i = 0; i<data.length;i++){
			if(data[i] == input){
				countOfNumbers[0]++;
			}
			if(data[i] > input){
				countOfNumbers[1]++;
			}
			if(data[i] < input){
				countOfNumbers[2]++;
			}
		}
		return countOfNumbers;
	}
	/*
	 * Displays the data of from countAboveAndBelow.
	 * @param countOfNumbers of type int[]
	 */
	public void displayAboveAndBelow(int[] countOfNumbers){
		//index = 0 is when data entry is the same as the input.
		//index = 1 is when data entry is above the input.
		//index = 2 is when data entry is below the input.
		try{
			System.out.println("Same number: "+ countOfNumbers[0]);
			System.out.println("Above: "+countOfNumbers[1]);
			System.out.println("Below: "+countOfNumbers[2]);
		}
		catch(Exception e){
			System.out.println("The count is null!");
		}
	}
	public static void main(String args[]){
		Scanner scan = new Scanner(System.in);
		Print_Numbers_Q1 Printer = new Print_Numbers_Q1(0,0);
		//Check if command line argument exist or not.
		String argument = "";
		while(args.length == 0){
			args = new String[1];
			System.out.println("What input would you like?");
			args[0] = scan.nextLine();
		}
		argument = args[0];
		Printer.setInput(argument);
		while(true){
			Printer.setCapacity(99);
			Printer.setArray(Printer.getCapacity());
			int dataValue[] = new int[Printer.getCapacity()];
			dataValue = Printer.getArray();
			Printer.displayAboveAndBelow(Printer.countAboveAndBelow(dataValue));
			System.out.println("Do you want to keep going: any capitalization of yes counts.");
			String checker = scan.next();
			//If it it not any form of 'yes' then the program stops running.
			if(!checker.equalsIgnoreCase("yes")){
				System.out.println("Done");
				break;
			}
			System.out.println("What input would you like?");
			String input = scan.next();
			Printer.setInput(input);
		}
	}
}