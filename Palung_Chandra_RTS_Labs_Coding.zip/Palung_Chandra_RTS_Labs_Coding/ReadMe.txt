In order to compile both files:
1. Be in the proper directory, and make sure the java path is correct.
2. There are 2 files.
   If compiling Print_Numbers_Q1.java,
      Command: 
      > javac Print_Numbers_Q1.java
   If running Print_Numbers_Q1,
     Command: 
     >java Print_Numbers_Q1 <input> 
     where input is a number. If not then it will go through a series of checks to ensure that the correct input is given.
  If compiling Rotate_Characters_Q2.java,
      Command: 
      > javac Rotate_Characters_Q2.java
   If running Rotate_Characters_Q2,
     Command: 
     >java Rotate_Q2 <input> 
     where input is a String. If not then it will go through a series of checks to ensure that the correct input is given.
